// Angry Bio: perfis em link (tipo guns.lol). Sem dependências. Rode: node server.js
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const PORT=process.env.PORT||3000,DIR=process.env.DATA_DIR||__dirname;
const F=path.join(DIR,'data.json'),UP=path.join(DIR,'uploads');fs.mkdirSync(UP,{recursive:true});
let D={users:{},sessions:{}};
try{const x=JSON.parse(fs.readFileSync(F));D.users=Object.fromEntries(Object.entries(x.users||{}).filter(([k,u])=>u.hash));D.sessions=x.sessions||{};if(Object.keys(D.users).length)console.log(Object.keys(D.users).length+' conta(s) carregada(s).')}catch(e){}
let dirty=0;setInterval(()=>{if(dirty){dirty=0;fs.writeFile(F,JSON.stringify(D),()=>{})}},2000);
const MT={png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',gif:'image/gif',webp:'image/webp',mp3:'audio/mpeg',ogg:'audio/ogg',wav:'audio/wav',m4a:'audio/mp4'};
const UPM={'image/png':'png','image/jpeg':'jpg','image/gif':'gif','image/webp':'webp','audio/mpeg':'mp3','audio/mp3':'mp3','audio/ogg':'ogg','audio/wav':'wav','audio/x-wav':'wav','audio/mp4':'m4a','audio/x-m4a':'m4a'};
const LIM={avatar:3e6,banner:6e6,icon:4e5,audio:15e6};
const RESERVED=['api','auth','upload','events','login','admin','signup','dash','dashboard','app','www','angry','index','shared','static','assets','perfil','profile'];
const rid=()=>crypto.randomBytes(6).toString('hex');
const json=(res,code,o)=>{res.writeHead(code,{'Content-Type':'application/json'});res.end(JSON.stringify(o||{ok:1}))};
const body=(req,max)=>new Promise((ok,no)=>{const a=[];let n=0;req.on('data',x=>{n+=x.length;if(n>max){no(new Error('big'));req.destroy()}else a.push(x)});req.on('end',()=>ok(Buffer.concat(a)));req.on('error',no)});
const hp=(pw,salt)=>crypto.scryptSync(pw,salt,64).toString('hex');
const same=(pw,u)=>{const a=Buffer.from(hp(pw,u.salt),'hex'),b=Buffer.from(u.hash,'hex');return a.length==b.length&&crypto.timingSafeEqual(a,b)};
const RL=new Map();const limited=ip=>{const n=Date.now(),r=RL.get(ip)||{n:0,t:n};if(n-r.t>6e4){r.n=0;r.t=n}r.n++;RL.set(ip,r);return r.n>10};
const SEEN=new Map();setInterval(()=>{const n=Date.now();for(const[k,t]of SEEN)if(n-t>18e5)SEEN.delete(k)},6e5);
const authOf=req=>{const t=(req.headers.authorization||'').replace(/^Bearer /,'');const s=D.sessions[t];return s&&Date.now()-s.ts<30*864e5&&D.users[s.aid]?s.aid:null};
const eh=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const FONTS=['Archivo','Pacifico','Bangers','Caveat','Orbitron','Permanent Marker','Press Start 2P'];
const DP=()=>({name:'',bio:'',bc:'#d6d7dc',status:'on',badges:'',bn:{g:0,img:'',anim:true},av:{img:'',emoji:'😡',shape:'circle',ring:'spin',rc:'#ff5a4f',float:true},nm:{font:'Archivo',c1:'#ff5a4f',c2:'#ffffff',anim:'s'},bt:[],mu:{url:'',title:'',emoji:'🎵',img:'',si:'🔊',viz:'bars',vc:'#ff5a4f',loop:true,vol:70},cd:{glow:true,gc:'#ff5a4f',blur:true,rad:20,bc:'#3a3b41'},bg:{t:'stars',c1:'#0e0f11',c2:'#3a3b41',img:''},sp:{on:true,text:'clique para entrar'},vw:true,tilt:true});
const DB={l:'Botão',e:'✨',ei:'',u:'',st:'solid',c:'#ff5a4f',sh:'pill',hv:'grow',an:'none'};
const SC={name:['s',24],bio:['s',200],bc:'c',status:['e',['on','idle','dnd','off']],badges:['s',16],bn:{g:['n',0,7],img:'i',anim:'b'},av:{img:'i',emoji:['s',8],shape:['e',['circle','squircle','square','hex']],ring:['e',['none','solid','spin','rainbow','pulse']],rc:'c',float:'b'},nm:{font:['e',FONTS],c1:'c',c2:'c',anim:['e',['n','g','s','r','nn','gl','w']]},mu:{url:'a',title:['s',60],emoji:['s',8],img:'i',si:['s',8],viz:['e',['bars','mirror','wave']],vc:'c',loop:'b',vol:['n',0,100]},cd:{glow:'b',gc:'c',blur:'b',rad:['n',0,40],bc:'c'},bg:{t:['e',['solid','grad','animgrad','stars','snow','bubbles','matrix','img']],c1:'c',c2:'c',img:'i'},sp:{on:'b',text:['s',40]},vw:'b',tilt:'b'};
const BS={l:['s',30],e:['s',8],ei:'i',u:'u',st:['e',['solid','outline','glass','neon','d3']],c:'c',sh:['e',['pill','rnd','sq']],hv:['e',['grow','shake','glow','flip','none']],an:['e',['none','pulse','float','wig']]};
function cl(v,sc,d){
  if(sc&&!Array.isArray(sc)&&typeof sc==='object'){const o={};v=v&&typeof v==='object'?v:{};for(const k in sc)o[k]=cl(v[k],sc[k],d[k]);return o}
  const[t,a,b]=Array.isArray(sc)?sc:[sc];
  if(t==='s')return typeof v==='string'?v.replace(/[\u0000-\u0009\u000b-\u001f]/g,'').slice(0,a):d;
  if(t==='c')return typeof v==='string'&&/^#[0-9a-f]{6}$/i.test(v)?v:d;
  if(t==='b')return typeof v==='boolean'?v:d;
  if(t==='n')return typeof v==='number'&&isFinite(v)?Math.min(b,Math.max(a,v)):d;
  if(t==='e')return a.includes(v)?v:d;
  if(t==='i')return typeof v==='string'&&(v===''||/^\/u\/[a-z0-9]+\.(png|jpe?g|gif|webp)$/.test(v))?v:d;
  if(t==='a')return typeof v==='string'&&(v===''||/^\/u\/[a-z0-9]+\.(mp3|ogg|wav|m4a)$/.test(v))?v:d;
  if(t==='u')return typeof v==='string'&&(v===''||/^https?:\/\/[^\s<>"']{1,200}$/i.test(v))?v:d;
  return d}
const cleanProf=p=>{p=p&&typeof p==='object'?p:{};const o=cl(p,SC,DP());o.bt=(Array.isArray(p.bt)?p.bt.slice(0,6):[]).map(b=>cl(b,BS,DB));return o};
const findU=n=>Object.entries(D.users).find(([k,x])=>x.user.toLowerCase()===String(n).toLowerCase());
const sendFile=(res,f,type)=>fs.readFile(path.join(__dirname,f),(e,b)=>{if(e){res.writeHead(404);return res.end()}res.writeHead(200,{'Content-Type':type});res.end(b)});
http.createServer(async(req,res)=>{
  const u=new URL(req.url,'http://x'),p=u.pathname,ip=(req.headers['x-forwarded-for']||req.socket.remoteAddress||'').split(',')[0].trim();
  if(req.method==='GET'){
    if(p==='/')return sendFile(res,'index.html','text/html; charset=utf-8');
    if(p==='/shared.js')return sendFile(res,'shared.js','application/javascript; charset=utf-8');
    if(p==='/shared.css')return sendFile(res,'shared.css','text/css; charset=utf-8');
    const im=p.match(/^\/u\/([a-z0-9]+\.(png|jpe?g|gif|webp|mp3|ogg|wav|m4a))$/);
    if(im){const f=path.join(UP,im[1]);return fs.stat(f,(e,st)=>{if(e){res.writeHead(404);return res.end()}
      const h={'Content-Type':MT[im[2]],'Cache-Control':'public, max-age=31536000, immutable','Accept-Ranges':'bytes'},m=/bytes=(\d*)-(\d*)/.exec(req.headers.range||'');
      if(m&&(m[1]||m[2])){const a=m[1]===''?Math.max(0,st.size-(+m[2])):+m[1],b=m[1]===''||m[2]===''?st.size-1:Math.min(+m[2],st.size-1);
        if(a>b||a>=st.size){res.writeHead(416);return res.end()}
        res.writeHead(206,{...h,'Content-Range':`bytes ${a}-${b}/${st.size}`,'Content-Length':b-a+1});return fs.createReadStream(f,{start:a,end:b}).pipe(res)}
      res.writeHead(200,{...h,'Content-Length':st.size});fs.createReadStream(f).pipe(res)})}
    if(p==='/api/me'){const aid=authOf(req);if(!aid)return json(res,401,{err:'Entre na sua conta.'});const x=D.users[aid];return json(res,200,{u:x.user,p:cleanProf(x.prof),views:x.views||0})}
    const ap=p.match(/^\/api\/p\/([A-Za-z0-9_]{3,20})$/);
    if(ap){const e=findU(ap[1]);if(!e)return json(res,404,{err:'Perfil não encontrado.'});const[aid,x]=e,k=ip+'|'+aid;
      if(!SEEN.has(k)){SEEN.set(k,Date.now());x.views=(x.views||0)+1;dirty=1}
      return json(res,200,{u:x.user,p:cleanProf(x.prof),views:x.views||0})}
    const pm=p.match(/^\/([A-Za-z0-9_]{3,20})$/);
    if(pm){const e=findU(pm[1]);let meta='<title>Perfil não encontrado · Angry</title>';
      if(e){const x=e[1],pr=cleanProf(x.prof),host=(req.headers['x-forwarded-proto']||'http')+'://'+req.headers.host,t=(pr.name||x.user)+' · Angry';
        meta=`<title>${eh(t)}</title><meta property="og:title" content="${eh(t)}"><meta property="og:description" content="${eh(pr.bio||'Meu perfil no Angry')}"><meta name="theme-color" content="${pr.bg.c1}"><meta name="twitter:card" content="summary">${pr.av.img?`<meta property="og:image" content="${eh(host+pr.av.img)}">`:''}`}
      return fs.readFile(path.join(__dirname,'profile.html'),'utf8',(er,h)=>{if(er){res.writeHead(500);return res.end()}res.writeHead(e?200:404,{'Content-Type':'text/html; charset=utf-8'});res.end(h.replace('<!--META-->',meta))})}
    res.writeHead(404);return res.end()}
  if(req.method==='POST'&&p==='/auth'){
    let d;try{d=JSON.parse((await body(req,1e4)).toString())}catch(e){return json(res,400,{err:'Pedido inválido.'})}
    if(d.act==='out'){const t=(req.headers.authorization||'').replace(/^Bearer /,'');delete D.sessions[t];dirty=1;return json(res,200)}
    if(limited(ip))return json(res,429,{err:'Muitas tentativas. Espere um minuto.'});
    const user=String(d.user||'').trim(),pw=String(d.pass||'');let aid;
    if(d.act==='reg'){
      if(!/^[a-zA-Z0-9_]{3,20}$/.test(user))return json(res,400,{err:'Usuário: 3 a 20 letras, números ou _.'});
      if(RESERVED.includes(user.toLowerCase()))return json(res,400,{err:'Esse nome é reservado. Escolha outro.'});
      if(pw.length<6||pw.length>100)return json(res,400,{err:'A senha precisa ter de 6 a 100 caracteres.'});
      if(findU(user))return json(res,409,{err:'Esse nome já foi escolhido por outra pessoa.'});
      aid=rid()+rid();const salt=crypto.randomBytes(16).toString('hex'),prof=DP();prof.name=user;
      D.users[aid]={user,salt,hash:hp(pw,salt),prof,views:0,ts:Date.now()}}
    else if(d.act==='login'){const e=findU(user);
      if(!e){hp(pw,'0000');return json(res,401,{err:'Usuário ou senha incorretos.'})}
      if(!same(pw,e[1]))return json(res,401,{err:'Usuário ou senha incorretos.'});aid=e[0]}
    else return json(res,400,{err:'Pedido inválido.'});
    for(const t in D.sessions)if(Date.now()-D.sessions[t].ts>30*864e5)delete D.sessions[t];
    const token=crypto.randomBytes(24).toString('hex');D.sessions[token]={aid,ts:Date.now()};dirty=1;return json(res,200,{token,u:D.users[aid].user})}
  if(req.method==='POST'&&p==='/upload'){const aid=authOf(req),kind=u.searchParams.get('kind'),ext=UPM[(req.headers['content-type']||'').split(';')[0]];
    if(!aid)return json(res,401,{err:'Entre na sua conta.'});
    if(!ext||!LIM[kind]||(kind==='audio')!==(MT[ext].startsWith('audio')))return json(res,400,{err:'Tipo de arquivo inválido.'});
    try{const b=await body(req,LIM[kind]),name=rid()+rid()+'.'+ext;fs.writeFileSync(path.join(UP,name),b);return json(res,200,{url:'/u/'+name})}
    catch(e){return json(res,413,{err:'Arquivo muito grande.'})}}
  if(req.method==='POST'&&p==='/api'){const aid=authOf(req);if(!aid)return json(res,401,{err:'Sessão expirada. Entre de novo.'});
    let d;try{d=JSON.parse((await body(req,2e5)).toString())}catch(e){return json(res,400,{err:'Pedido inválido.'})}
    if(d.type==='profile'){D.users[aid].prof=cleanProf(d.prof);dirty=1;return json(res,200)}
    return json(res,400,{err:'Pedido inválido.'})}
  res.writeHead(404);res.end();
}).listen(PORT,()=>console.log('Angry Bio rodando em http://localhost:'+PORT+'  (perfis em http://localhost:'+PORT+'/seunome)'));
