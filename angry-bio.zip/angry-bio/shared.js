const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const ST={on:'#3ddc97',idle:'#ffb020',dnd:'#ff5a4f',off:'#6b5553'},SR={circle:'50%',squircle:'28%',square:'8px',hex:'0'};
const GR=['linear-gradient(120deg,#3a3b41,#52535a,#2a2b2f,#5a5b62)','linear-gradient(120deg,#ff5a4f,#ff9a3c,#ff3c7a,#ff5a4f)','linear-gradient(120deg,#0f2027,#2c5364,#00c6ff,#0f2027)','linear-gradient(120deg,#f093fb,#f5576c,#4facfe,#f093fb)','linear-gradient(120deg,#11998e,#38ef7d,#0b6e4f,#11998e)','linear-gradient(120deg,#232526,#414345,#000,#232526)','linear-gradient(120deg,#fceabb,#f8b500,#ff6a00,#fceabb)','linear-gradient(120deg,#41295a,#2f0743,#8e2de2,#41295a)'];
/* ---------- cartão de perfil ---------- */
function cardH(p,u,on){const a=p.av,r=SR[a.shape],sz=86,w=p.nm.anim=='w'?[...(p.name||u)].map((c,i)=>`<span style="animation-delay:${i*90}ms">${c==' '?'&nbsp;':esc(c)}</span>`).join(''):esc(p.name||u),m=p.mu;
return `<div class="pcard ${p.cd.blur?'bl':''}" style="border-color:${esc(p.cd.bc)};border-radius:${p.cd.rad}px;box-shadow:${p.cd.glow?`0 0 40px ${esc(p.cd.gc)}66,0 0 10px ${esc(p.cd.gc)}55`:'0 10px 30px #0006'}">
<div class="bn ${p.bn.anim&&!p.bn.img?'an':''}" style="background-image:${GR[p.bn.g]}">${p.bn.img?`<img src="${esc(p.bn.img)}" alt="">`:''}</div>
<div class="in"><div class="ar"><div class="ring ${a.ring} ${a.float?'fl2':''} ${a.shape=='hex'?'hex':''}" style="--r:${r};--rc:${esc(a.rc)}"><div class="av" style="width:${sz}px;height:${sz}px;font-size:${sz*.5}px;--r:${r}">${a.img?`<img src="${esc(a.img)}" alt="">`:esc(a.emoji||'🙂')}</div></div>${a.shape=='hex'?'':`<span class="st" style="background:${ST[p.status]}"></span>`}</div>
<h2 class="nm nmc n-${p.nm.anim}" style="--c1:${esc(p.nm.c1)};--c2:${esc(p.nm.c2)};font-family:'${esc(p.nm.font)}',sans-serif;font-size:28px">${w}</h2><div class="hd2">@${esc(u)}${on===true?' · <span style="color:#3ddc97">online</span>':on===false?' · offline':''}</div>
${p.badges?`<div class="bg">${esc(p.badges)}</div>`:''}${p.bio?`<p class="bi" style="color:${esc(p.bc)}">${esc(p.bio)}</p>`:''}
${m.url?`<div class="pl" style="--vc:${esc(m.vc)}"><div class="pc">${m.img?`<img src="${esc(m.img)}" alt="">`:esc(m.emoji)}</div><div class="pm"><div class="pt">${esc(m.title||'Música')}</div><canvas id="vz" height="36"></canvas><input type="range" class="sk" id="sk" min="0" max="1000" value="0" aria-label="Posição da música"></div><div class="pr"><button class="pbt" data-pl="play" aria-label="Tocar ou pausar">▶</button><button class="pms" data-pl="mute" aria-label="Mudo">${esc(m.si)}</button></div></div>`:''}
<div class="bts">${p.bt.map(b=>{const l=b.u?`a href="${esc(b.u)}" target="_blank" rel="noopener noreferrer"`:'button type="button"',tg=l.split(' ')[0];return `<${l} class="pb ${b.st=='d3'?'d3':b.st} ${b.sh} ${b.hv} ${b.an!='none'?'a-'+b.an:''}" style="--c:${esc(b.c)}">${b.ei?`<img class="bim" src="${esc(b.ei)}" alt="">`:esc(b.e)} ${esc(b.l)}</${tg}>`}).join('')}</div></div></div>`}
/* ---------- áudio com visualizador ---------- */
const aud=new Audio();aud.preload='auto';let AC,AN,FD,MU=null;
['play','pause','ended','timeupdate','loadedmetadata'].forEach(v=>aud.addEventListener(v,()=>sync()));
function bindAudio(m){MU=m;const u=m.url||'';if((aud.getAttribute('src')||'')!==u){aud.pause();u?aud.src=u:aud.removeAttribute('src')}aud.volume=m.vol/100;aud.loop=!!m.loop;sync()}
function initA(){if(AC)return;try{AC=new(window.AudioContext||window.webkitAudioContext)();const s=AC.createMediaElementSource(aud);AN=AC.createAnalyser();AN.fftSize=128;s.connect(AN);AN.connect(AC.destination);FD=new Uint8Array(AN.frequencyBinCount)}catch(e){AC=null;AN=null}}
async function toggle(){if(!aud.getAttribute('src'))return;initA();if(AC&&AC.state=='suspended')await AC.resume();aud.paused?aud.play().catch(()=>{}):aud.pause()}
function sync(){const pl=$('.pl');if(!pl||!MU)return;pl.classList.toggle('on',!aud.paused);$('[data-pl=play]').textContent=aud.paused?'▶':'⏸';$('[data-pl=mute]').textContent=aud.muted?'🔇':MU.si;const sk=$('#sk');if(sk&&aud.duration&&!sk.matches(':active'))sk.value=aud.currentTime/aud.duration*1000;viz()}
function viz(){const c=$('#vz');if(!c||!MU)return;const w=c.clientWidth||300,h=36;if(c.width!=w)c.width=w;const x=c.getContext('2d'),on=!aud.paused&&AN;x.clearRect(0,0,w,h);x.fillStyle=x.strokeStyle=MU.vc;const t=MU.viz;
if(t=='wave'){x.lineWidth=2;x.beginPath();if(on){AN.getByteTimeDomainData(FD);for(let i=0;i<FD.length;i++){const X=i/(FD.length-1)*w,Y=FD[i]/255*h;i?x.lineTo(X,Y):x.moveTo(X,Y)}}else{x.moveTo(0,h/2);x.lineTo(w,h/2)}x.stroke();return}
if(on)AN.getByteFrequencyData(FD);const n=32,bw=w/n;for(let i=0;i<n;i++){const v=on?FD[Math.floor(i*FD.length*.7/n)]/255:.06,bh=Math.max(2,v*h);x.fillRect(i*bw+1,t=='mirror'?(h-bh)/2:h-bh,bw-3,bh)}}
(function lp(){viz();requestAnimationFrame(lp)})();
/* ---------- fundo animado ---------- */
let BGK='',BGO=null,BGS,BGC,PT=[],MC=[],LF=0;const RM=matchMedia('(prefers-reduced-motion:reduce)').matches;
function bgSet(st,cv,bg){const k=JSON.stringify(bg);if(k===BGK&&st===BGS)return;BGK=k;BGS=st;BGC=cv;BGO=bg;const t=bg.t;st.classList.toggle('anim',t=='animgrad');
st.style.background=t=='img'&&bg.img?`${bg.c1} url("${bg.img}") center/cover no-repeat`:/^(solid|stars|snow|bubbles|matrix)$/.test(t)?bg.c1:`linear-gradient(135deg,${bg.c1},${bg.c2},${bg.c1})`;bgInit()}
function bgInit(){const c=BGC;c.width=c.clientWidth||innerWidth;c.height=c.clientHeight||innerHeight;const w=c.width,h=c.height,t=BGO.t;PT=[];MC=[];c.getContext('2d').clearRect(0,0,w,h);
if(t=='stars')for(let i=0;i<130;i++)PT.push({x:Math.random()*w,y:Math.random()*h,r:Math.random()*1.6+.3,s:Math.random()*6});
if(t=='snow')for(let i=0;i<100;i++)PT.push({x:Math.random()*w,y:Math.random()*h,r:Math.random()*3+1,v:Math.random()+.4,s:Math.random()*6});
if(t=='bubbles')for(let i=0;i<40;i++)PT.push({x:Math.random()*w,y:Math.random()*h,r:Math.random()*18+4,v:Math.random()*.8+.3,s:Math.random()*6});
if(t=='matrix')for(let i=0;i<Math.ceil(w/16);i++)MC.push(Math.random()*h/16)}
function bgFrame(t){const c=BGC,x=c.getContext('2d'),w=c.width,h=c.height,T=BGO.t;
if(T=='matrix'){x.globalAlpha=.12;x.fillStyle=BGO.c1;x.fillRect(0,0,w,h);x.globalAlpha=1;x.fillStyle='#3ddc97';x.font='14px monospace';MC.forEach((y,i)=>{x.fillText(String.fromCharCode(0x30A0+Math.random()*60),i*16,y*16);MC[i]=y*16>h&&Math.random()>.975?0:y+1});return}
if(!PT.length)return;x.clearRect(0,0,w,h);PT.forEach(p=>{x.beginPath();
if(T=='stars'){x.globalAlpha=.4+.6*Math.abs(Math.sin(t/700+p.s));x.fillStyle='#fff';x.arc(p.x,p.y,p.r,0,7);x.fill()}
else if(T=='snow'){p.y+=p.v;p.x+=Math.sin(t/900+p.s)*.4;if(p.y>h)p.y=-5;x.globalAlpha=.8;x.fillStyle='#fff';x.arc(p.x,p.y,p.r,0,7);x.fill()}
else{p.y-=p.v;p.x+=Math.sin(t/800+p.s)*.3;if(p.y<-30)p.y=h+30;x.globalAlpha=.35;x.strokeStyle=BGO.c2;x.lineWidth=2;x.arc(p.x,p.y,p.r,0,7);x.stroke()}});x.globalAlpha=1}
(function bl(t){if(BGO&&BGC&&!RM&&t-LF>(BGO.t=='matrix'?55:16)){LF=t;const c=BGC;if(c.width!=c.clientWidth||c.height!=c.clientHeight)bgInit();bgFrame(t)}requestAnimationFrame(bl)})(0);
addEventListener('resize',()=>BGO&&bgInit());
document.addEventListener('click',e=>{const b=e.target.closest('[data-pl]');if(!b)return;if(b.dataset.pl=='play')toggle();else{aud.muted=!aud.muted;sync()}});
document.addEventListener('input',e=>{if(e.target.id=='sk'&&aud.duration)aud.currentTime=e.target.value/1000*aud.duration});
